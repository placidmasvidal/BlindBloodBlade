package com.xaviplacidpol.blindbloodblade.utils;

public class SetupValues {

    public static boolean music = true;
    public static boolean sound = true;

}
